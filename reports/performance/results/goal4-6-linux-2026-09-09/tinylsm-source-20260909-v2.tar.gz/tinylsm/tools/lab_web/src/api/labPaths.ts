const fallbackExperimentDirectory = '/tmp/tinylsm-lab/session-demo'

/**
 * Local-only configuration lets each developer choose where a Lab session
 * writes its WAL, MANIFEST, and SSTable files without committing that path.
 */
export const defaultExperimentDirectory =
  import.meta.env.VITE_LAB_EXPERIMENT_DIRECTORY?.trim() || fallbackExperimentDirectory
