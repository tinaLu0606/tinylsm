# TinyLSM

TinyLSM is a compact C++20 key-value storage engine built to explore the core
mechanics of an LSM tree: write-ahead logging, ordered in-memory state, immutable
SSTables, manifest-based recovery, tombstones, checksums, and crash-aware file
publication. New tables use a versioned prefix-compressed SSTable v2 format;
the Reader remains compatible with v1 tables. The engine also exposes
process-local Snapshot reads and pull-based iterators over a consistent MVCC view.

The project is intentionally small enough to inspect end to end. It is a
learning-oriented prototype rather than a production database. The write path
uses an active WAL/MemTable plus one bounded immutable WAL/MemTable generation:
rotation is durable before a single background worker flushes the immutable
generation into an ordered set of SSTables. Range scans lazily merge active
memory, immutable memory, and tables. A bounded worker then performs simplified
size-tiered compaction of the oldest table prefix when its table-count trigger
is reached; callers can still run an explicit synchronous full compaction.
Creating `Get`, `Scan`, a Snapshot, or an Iterator briefly shares the state
lock; a public Iterator then owns its captured MemTable entries and SSTable
reader references, so long `Next()` loops do not hold the DB state lock.

## Quick start

### Requirements

- CMake 3.24 or newer
- Ninja
- A C++20 compiler
- GoogleTest for normal test builds; the sanitizer preset fetches a pinned
  source copy so the test framework receives the same instrumentation
- Protobuf (if it is not installed, CMake fetches the pinned v29.3 source)
- Node.js and npm when developing the optional Lab UI

On macOS, the main build dependencies can be installed with Homebrew:

```sh
brew install cmake ninja googletest protobuf
```

Build the project and run the Debug test suite:

```sh
./run test
```

Run the sanitizer configuration:

```sh
./run asan
./run tsan
```

`run` is the repository's Bash entry point. It translates short developer
commands into the corresponding CMake, build, test, formatting, or lint command.
Use `./run help` to see the current command list.

## CLI usage

The CLI opens the database for one operation and closes it before returning. The
database directory is created automatically when it does not exist.

```sh
./run cli -- /tmp/tinylsm-demo put name Tina
./run cli -- /tmp/tinylsm-demo get name
./run cli -- /tmp/tinylsm-demo put city Singapore
./run cli -- /tmp/tinylsm-demo scan
./run cli -- /tmp/tinylsm-demo delete name
./run cli -- /tmp/tinylsm-demo get name
```

`scan` accepts an optional half-open key range, `[begin, end)`:

```sh
./run cli -- /tmp/tinylsm-demo scan a n
```

For machine-readable `get` and `scan` output, add `--json`:

```sh
./run cli -- /tmp/tinylsm-demo get city --json
./run cli -- /tmp/tinylsm-demo scan --json
```

JSON output is JSON Lines. Keys and values are Base64 encoded so arbitrary bytes
can be represented without escaping or encoding ambiguity. Command-line
arguments themselves remain subject to shell limitations; binary applications
should use the C++ API.

## TinyLSM Lab

The experimental React and TypeScript frontend is maintained as the
`tools/lab_web` Git submodule. A fresh checkout can build and start the local
Lab with one command:

```sh
git submodule update --init tools/lab_web
./run lab
```

Then open the URL printed by the server (by default
`http://127.0.0.1:8080`). `./run lab` installs the frontend dependencies when
needed, builds the frontend with the live transport selected, builds the C++
server, and serves the packaged UI and API from that one loopback process.
Pass server options after `--`, for example `./run lab -- --port 18080`.

For frontend-only work, start Vite separately:

```sh
cd tools/lab_web
VITE_LAB_API=live npm run dev
```

`tinylsm_lab_server` links TinyLSM directly; it never shells out to the CLI.
It accepts Open, Close, Reopen, Put, Get, Delete, Scan and Compact on one
serialized session, exposes copied internal diagnostic snapshots, lists real
directory files, retains the latest 10,000 detailed operation/event records,
and serves SSE events with `Last-Event-ID` replay. Storage inspection reads
Manifest, WAL records, SSTable blocks, and hexadecimal file ranges through
bounded, paged APIs. The server also records bounded latency/resource series,
rotates detailed session event logs as JSONL, and runs deterministic seeded
workloads against a server-side ordered reference map. High-rate workloads keep
only aggregates and a first failure sample; they do not persist every operation.
The Recovery workspace first copies the currently open database into a
server-created temporary sandbox. Its three scenarios exercise a no-`Close()`
worker exit, a one-byte WAL-tail truncation, and Manifest CRC corruption. Only
the sandbox is mutated; preview, run, reset, and audit events are all exposed
by the API. Recovery paths are never accepted from the browser.
It only listens on `127.0.0.1` (or `::1` when embedded) and limits JSON request
bodies to 8 MiB. `cpp-httplib` v0.18.0 and `nlohmann/json` v3.11.3 are pinned
through CMake FetchContent for this local tool.

Pass `--static-dir tools/lab_web/dist` after `npm run build` to have the same
server also serve the packaged frontend; Vite remains useful for live frontend
development.

Live data is labelled `Live`; it is never filled from Mock fixtures. See
`tools/lab_web/README.md` for the frontend transport boundary and verification
steps.

## Developer commands

| Command | Purpose |
| --- | --- |
| `./run configure [preset]` | Generate build files without compiling |
| `./run build [preset]` | Configure and compile the selected preset |
| `./run test [preset]` | Configure, compile, and run CTest |
| `./run cli -- <args>` | Build and run `tinylsm_cli` |
| `./run lab [-- <server args>]` | Build the live Lab UI and serve it with the loopback Lab API |
| `./run format [--check]` | Apply or verify `clang-format` |
| `./run lint [preset]` | Run `clang-tidy` with the preset compilation database |
| `./run asan` | Build and test with AddressSanitizer and UBSan |
| `./run tsan` | Build and test with ThreadSanitizer |
| `./run release` | Build the Release preset |
| `./run benchmark [-- <args>]` | Build and run the pinned Release benchmark suite |
| `./run clean [preset]` | Clean the selected build tree |

Available CMake presets are:

- `dev-debug`: Debug build with tools and tests.
- `dev-asan-ubsan`: Debug build with AddressSanitizer and UndefinedBehaviorSanitizer.
- `dev-tsan`: Debug build with ThreadSanitizer.
- `release`: optimized build without the test targets.
- `benchmark`: optimized benchmark build with pinned Google Benchmark and,
  by default, pinned LevelDB comparison targets.

The `package` command is reserved for future install/CPack support and currently
reports that packaging is not implemented.

## Public C++ API

The public interface is deliberately small: `Open`, `Put`, `Get`, `Delete`,
atomic `Write`, `Scan`, `Compact`, and `Close`. Expected storage failures are
returned through `Status` and `Result<T>` instead of exceptions.

```cpp
#include <iostream>
#include <utility>

#include "tinylsm/db.h"

int main() {
  auto opened = tinylsm::DB::Open("/tmp/tinylsm-api-demo");
  if (!opened.ok()) {
    std::cerr << opened.status().ToString() << '\n';
    return 1;
  }

  auto db = std::move(opened.value());

  auto status = db->Put("language", "C++");
  if (!status.ok()) {
    std::cerr << status.ToString() << '\n';
    return 1;
  }

  auto value = db->Get("language");
  if (value.ok())
    std::cout << value.value() << '\n';

  status = db->Close();
  return status.ok() ? 0 : 1;
}
```

Keys and values are byte strings. Database handles are movable but non-copyable.
`Get`, `Scan`, Snapshot creation, and Iterator creation share a read lock;
writes, compaction, and close use the exclusive state boundary. Moving or
destroying a handle still requires exclusive ownership.

`WriteBatch` groups several ordered `Put`/`Delete` operations into one WAL
record and one optional WAL sync. Concurrent public requests enter a bounded
group-commit queue; a leader may encode several complete batches into one
physical WAL frame and sync. Recovery applies a complete frame in full and
discards an incomplete final frame in full, so a crash cannot expose half of a
public batch. This is atomicity, not isolation across multiple DB handles and
not rollback-capable transactions.

```cpp
tinylsm::WriteBatch batch;
batch.Put("account:a", "90");
batch.Put("account:b", "110");
auto status = db->Write(batch);
```

`GetSnapshot()` pins the current logical sequence without copying the database.
Pass that handle to `Get` or `NewIterator` to read the same view while writers,
flush, and compaction continue. Snapshots are process-local and are not valid
after reopen; `Options::max_active_snapshots` defaults to 1,024 to make a
forgotten retention handle a bounded resource error.

```cpp
auto snapshot = db->GetSnapshot();
auto old_value = db->Get("account:a", snapshot.value().get());
auto it = db->NewIterator({}, {}, snapshot.value().get());
while (it.value()->Valid())
  it.value()->Next();
```

`GetSnapshotMetrics()` reports active Snapshot count, its oldest sequence, and
versions/bytes retained by the last full-table compaction. A live Snapshot can
retain old versions at approximately `overwrite rate × average record bytes × age`.

`GetWriteMetrics()` returns cumulative, point-in-time write-path counters for
one handle: WAL syncs, physical groups, grouped request count, writer-queue
wait/depth, MemTable rotations, successful/failed background flushes, and
immutable-generation queue depth/bytes. It is an observability aid, not a
latency benchmark by itself.

`GetReadMetrics()` additionally exposes raw point-lookup, range-scan, table-probe
and scan-table-input counts. `GetCompactionMetrics()` exposes compaction
input/output table and physical-byte counters, current table count, live SSTable
bytes, and table/byte debt. Together with workload logical bytes these permit
recomputing read, write, and space amplification rather than relying on a single
opaque score.

## Implemented scope

- WAL-first `Put`, `Delete`, and atomic `WriteBatch`, with a bounded
  group-commit queue, optional per-group synchronization, active/immutable WAL
  rotation, and one bounded background MemTable flush worker.
- An ordered MemTable and SSTable v2 format that retain MVCC versions in
  `(user key, sequence descending)` order. v2 prefix-compresses user keys,
  persists restart offsets and checksummed table properties, while retaining
  v1 read compatibility.
- Immutable, block-indexed SSTables with CRC32C integrity checks and complete
  validation of Manifest-referenced table data during startup.
- Tombstones that hide deleted values across memory and disk.
- Pull-based public Iterators and half-open materialized Scans over active
  MemTable, immutable MemTable, and SSTable state, with optional Snapshots.
- Default bounded background size-tiered compaction: once four tables are live,
  merge the oldest contiguous prefix into zero or one replacement. Set
  `Options::compaction_table_trigger = 0` to disable automatic scheduling.
- Explicit synchronous full compaction into zero or one replacement SSTable.
- A version-3 Manifest snapshot that records active and optional immutable WALs,
  the ordered SSTable set, and sequence state while retaining version-1 and
  version-2 read compatibility.
- Startup recovery through Manifest loading, immutable-WAL replay, then
  active-WAL replay.
- Conservative orphan cleanup for canonical numbered WAL/SSTable names after
  successful recovery and at later maintenance checkpoints.
- Detection of malformed records, truncated data, checksum failures, invalid
  ordering, missing files, and size mismatches.
- Serialized public DB operations with concurrent integration coverage.
- Unit, integration, CLI, fault-injection, and recovery tests, plus ASan/UBSan
  and TSan test builds.
- A Release benchmark suite with fixed workloads and a pinned LevelDB adapter.

## Architecture

```text
                 +-------------------------------+
                 |  C++ API / tinylsm_cli        |
                 +---------------+---------------+
                                 |
                                 v
                 +-------------------------------+
                 |  DB facade + DB::Impl         |
                 |  validation and orchestration |
                 +-----+-----------+-------------+
                       |           |
              writes   |           | reads / scans
                       v           v
                 +-----------+  +-----------+
                 |    WAL    |  | MemTable  |
                 | append +  |  | ordered   |
                 | replay    |  | MVCC keys |
                 +-----------+  +-----+-----+
                                        |
                                        | flush
                                        v
                                  +-----------+
                                  | SSTables  |
                                  | blocks +  |
                                  | indexes   |
                                  +-----------+

                 +-------------------------------+
                 | Manifest                      |
                 | authoritative file metadata   |
                 +-------------------------------+

                 All persistent I/O passes through
                 the FileSystem abstraction.
```

The main modules are:

- `include/tinylsm`: stable public types and database API.
- `src/db`: operation orchestration and lifecycle management.
- `src/memtable`: ordered in-memory key state.
- `src/wal`: WAL record codec, writer, and recovery reader.
- `src/sstable`: immutable table builder, reader, block index, and format.
- `src/manifest`: persistent metadata codec and publication protocol.
- `src/io`: filesystem interfaces and POSIX implementation.
- `src/iterator`: internal merge iteration shared by scans and compaction.
- `tools/cli`: argument parsing and CLI command handlers.
- `tools/lab_web`: experimental Lab UI maintained as a Git submodule.

## Core data flows

### Write path

```text
Put/Delete or WriteBatch
    -> validate and enter the bounded writer queue
    -> leader assigns consecutive sequences to complete requests
    -> append one complete WAL batch for the selected group
    -> optionally fsync WAL once for that group
    -> apply every group entry to MemTable, then wake callers
    -> when full, create next active WAL and durably publish
       {active WAL, one immutable WAL} in Manifest v3
    -> move old MemTable/WAL to the one-item immutable generation
    -> one background worker builds and verifies its SSTable
    -> durably publish the SSTable and clear immutable WAL from Manifest
    -> best-effort remove the now-unreferenced immutable WAL

If a second active generation fills while the immutable one is still pending,
the foreground writer waits. This bounds the asynchronous write queue at one
immutable MemTable/WAL pair instead of admitting unbounded memory. A background
failure becomes sticky for later data operations and `Close`; a caller closes
and reopens after a visible-but-not-durable Manifest publication failure.
```

Every delete is stored as a tombstone rather than removing older bytes in place.
The simplified background strategy only compacts the oldest table prefix, so it
may discard an input tombstone only because no unselected older table exists.
Newer tables and memory retain their higher-sequence visibility. Other partial
selection shapes would have to preserve the tombstone.

### Read and scan paths

`Get` selects the largest sequence no later than the requested Snapshot from
the active MemTable, immutable MemTable, and live SSTables. A tombstone is
returned internally as the selected state but exposed to the caller as
`NotFound`.

`NewIterator` captures MemTable versions and shared SSTable readers, then
lazily merges them in byte-wise key order and filters to each key's visible
sequence. It is pull-based: only `Next()` advances it. SSTable iterators keep
at most one decoded block at a time. `Scan` uses this same path but materializes
the final `vector<Entry>`; a later block failure makes the materialized Scan
fail instead of returning a partial result.

### Asynchronous flush commit protocol

```text
active MemTable/WAL reaches threshold
    -> create and sync the replacement active WAL
    -> Manifest v3: old WAL becomes immutable, replacement is active
                                               <- rotation commit point
    -> background worker builds, validates, renames, and directory-syncs SST
    -> Manifest v3: add SSTable and clear immutable WAL
                                               <- flush commit point
    -> release immutable MemTable and best-effort remove its old WAL
```

### Compaction commit protocol

Automatic compaction merges the oldest contiguous table prefix through the same
internal iterator path as `Scan`. A partial prefix preserves all versions; a
full-table compaction retains every version newer than the oldest active
Snapshot plus one version visible at that watermark. With no active Snapshot it
keeps only the latest live value and can discard its tombstone. The worker
durable-reserves its output number before reading its shared reader snapshot
outside the state lock; flush and compaction serialize their Manifest updates at
the same state boundary.

`Compact()` remains a synchronous full-table maintenance operation. It waits for
background work, keeps the historical single-Manifest fault boundary, and does
not flush the MemTable or replace the active WAL.

```text
oldest N SSTables (background) or all tables (explicit)
    -> merge selected entries and build a replacement when a live value exists
    -> verify, rename, and directory-sync the replacement SSTable
    -> publish a Manifest replacing only the selected prefix <- commit point
    -> replace the corresponding shared reader set
    -> best-effort remove the old SSTables
```

A failure before Manifest publication leaves the old table set authoritative.
If the Manifest rename is visible but its directory sync fails, the current DB
handle rejects further data operations until it is closed and reopened.

### Orphan cleanup

Numbered files use canonical decimal names: numbers below one million are padded
to six digits, while larger numbers grow naturally. After complete recovery,
TinyLSM removes canonical `.wal`, `.sst`, `.sst.tmp`, and `MANIFEST.tmp` files
that are not referenced by the current Manifest. Noncanonical lookalikes and
unrelated files are always preserved. Listing, removal, or directory-sync
failures do not invalidate recovered data; later Open, flush, or compaction
attempts retry cleanup.

Before the Manifest rename, the old Manifest, WAL, and MemTable remain
authoritative even if the attempted flush created orphan files. A successful
Manifest rename makes the replacement visible; syncing the database directory
makes that replacement durable. If the directory sync fails, the current handle
enters a terminal error state because the replacement may be visible without a
durability guarantee, and the caller must close and reopen the database.

### Recovery path

```text
Open database
    -> load the authoritative Manifest
    -> validate and open every referenced SSTable
    -> read all live data blocks and verify true key/sequence metadata
    -> replay the optional immutable WAL, then the active WAL, into their
       corresponding MemTables
    -> require every replayed WAL sequence to increase beyond the published
       sequence and the previous replayed WAL
    -> truncate an incomplete WAL tail when recoverable
    -> continue from the highest recovered sequence number
    -> remove only canonical files not referenced by the recovered Manifest
```

Checksums detect accidental corruption in encoded WAL records, SSTable blocks,
and persisted metadata. Structural validation separately checks lengths, file
boundaries, ordering, indexes, and sequence metadata.

The WAL reader accepts the original version-1 single-operation records and the
version-2 batch record. A batch contains consecutive sequence numbers and one
checksum covering its complete payload; mixed old and new records can therefore
be recovered during an in-place format transition.

Manifest version 3 stores an active WAL, an optional immutable WAL, and live
tables in oldest-to-newest order, protected by CRC32C over its header and
Protobuf payload. The reader accepts fixed version-1 and version-2 snapshots,
which have no immutable WAL. SSTable v2 adds checksummed entry-count, key-range,
and sequence-range properties, but startup deliberately still reads every live
data block to verify those properties and the Manifest metadata; Open therefore
remains `O(total live SSTable bytes)`.

## Current limitations

TinyLSM currently favors clarity and testability over feature breadth:

- The automatic strategy is intentionally one simplified size-tiered oldest-prefix
  merge, not leveled compaction: it has no level metadata, overlap selection,
  bandwidth throttling, rate limiter, or multiple compaction workers.
- A reader retained by a background input snapshot may keep an old SSTable handle
  open until that job finishes; obsolete files are best-effort unlinked only after
  the durable Manifest commit.
- There is no Bloom filter. SSTable decoded blocks have an in-memory bounded
  LRU cache (8 MiB by default; `Options::block_cache_bytes = 0` disables it).
  The cache is not persistent and only stores successfully validated blocks.
- With the decoded-block cache disabled, v2 point lookup uses restart offsets
  to search and reconstruct one restart group. With caching enabled it uses the
  complete validated decoded block; no before/after performance result is
  claimed yet.
- Snapshots provide only read-only, process-local sequence visibility; there is
  no read-write transaction, conflict detection, serializable isolation, or
  general rollback facility. `Options::max_active_snapshots` bounds handle
  count but not the bytes retained by a long-lived handle.
- The POSIX filesystem path is the implemented persistent backend.
- Packaging and installation rules are not implemented yet.

These constraints keep the durability boundary, recovery rules, and on-disk
formats visible while leaving clear next steps toward a fuller LSM engine.

## Performance baseline

The reproducible Release workloads, raw JSON output, macOS pre/post comparison,
same-machine Linux/LevelDB results, and fixed Lima VM definition are documented in
[`reports/performance/baseline-2026-09-06.md`](reports/performance/baseline-2026-09-06.md).
The follow-up work is split into independently verifiable Codex goals in
[`docs/plans/performance/performance-extension-roadmap.md`](docs/plans/performance/performance-extension-roadmap.md).
Goal 1's fixed-Linux profile, raw before/after JSON, cache accounting, and
concurrency result are in
[`reports/performance/read-path-2026-09-07.md`](reports/performance/read-path-2026-09-07.md).
Goal 3's strategy decision, tombstone rule, raw metric contract, two fixed-Linux
JSON runs, tail-latency/space-amplification evidence, and acceptance results are in
[`reports/performance/compaction-design-and-results-2026-09-08.md`](reports/performance/compaction-design-and-results-2026-09-08.md).
Goal 2's bounded asynchronous-write design, two fixed-Linux raw JSON runs,
latency/stall/RSS evidence, and failure boundary are in
[`reports/performance/write-path-2026-09-07.md`](reports/performance/write-path-2026-09-07.md).
The Goal 1-3 evidence index, conditional deferrals, and fixed-Linux Release CLI
deployment-smoke evidence are in
[`reports/performance/performance-extension-closeout-2026-09-08.md`](reports/performance/performance-extension-closeout-2026-09-08.md).
The baseline is descriptive and is not yet a CI performance gate.
The baseline's recorded Linux run passed 97/97 tests in Debug, ASan/UBSan, and
Clang TSan, plus the Release build and deployment smoke test. Recreate it with
`tools/vm/tinylsm-linux.yaml`, then run `./scripts/run_linux_baseline.sh` or the
Goal 3 `./scripts/run_linux_compaction_goal3.sh <output-dir>` inside the VM to
retain the environment, test logs, Release build log, complete benchmark JSON,
and verification evidence in one output directory.

Goals 4-6 have a separately prepared, Release-only fixed-Linux runner:
`./scripts/run_linux_next_goals.sh <output-dir>`. It records two raw JSON runs
for Snapshot/Iterator, SSTable v2 format, and bounded Group Commit, then rejects
any case whose two-run median CV exceeds 10%. Its matrix and interpretation
limits are in
[`docs/plans/performance/goals-4-6-experiment-contract-2026-09-09.md`](docs/plans/performance/goals-4-6-experiment-contract-2026-09-09.md).
The two retained runs completed all 38 median cases with cross-run real-time CV
at or below 3.645%. The detailed post-optimization report, raw-data index, and
the discovered single-operation write regression are in
[`reports/performance/portfolio-benchmark-2026-09-09.md`](reports/performance/portfolio-benchmark-2026-09-09.md).
